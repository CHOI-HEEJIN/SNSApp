package co.kr.newp;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;


@SuppressLint("JavascriptInterface") public class MainActivity extends Activity implements LocationListener {
WebView webView;
static TextView tx1,tx2;
static TextView tx_weight,tx_btn_weight;
ImageView img_mypoint,img_mypoint1;
private Location myLocation = null;
private double latPoint, lngPoint;
private Geocoder geoCoder;
private LocationManager locManager;
static Activity actimain;
static String arrange;

ImageView img2,img3,img4,img5;
TextView tx11,tx22,tx33;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    	webView = (WebView)findViewById(R.id.map_wb1);
    	  geoCoder = new Geocoder(this, Locale.KOREA);
    	  actimain=MainActivity.this;
    	  
    	  tx11=(TextView) findViewById(R.id.tx1);
  		tx22=(TextView) findViewById(R.id.tx2);
  		tx33=(TextView) findViewById(R.id.tx3);
  		img2=(ImageView) findViewById(R.id.img2);
  		img3=(ImageView) findViewById(R.id.img3);
  		img4=(ImageView) findViewById(R.id.img4);
  		img5=(ImageView) findViewById(R.id.img5);
  		setbtnexe();
    	
    	
		setWebViewSetting();
		webView.loadUrl("http://dna110.dothome.co.kr/footprint/map.html");
		webView.addJavascriptInterface(new androidbrd(), "android");
		tx1=(TextView) findViewById(R.id.map_dis);
		tx2=(TextView) findViewById(R.id.map_exer);
		tx_weight=(TextView) findViewById(R.id.map_ed1);
		tx_btn_weight=(TextView) findViewById(R.id.tx_btn_weight);
		img_mypoint=(ImageView) findViewById(R.id.map_mypoint);
		img_mypoint1=(ImageView) findViewById(R.id.map_mypoint1);
		
		
		locManager = (LocationManager)getSystemService(getApplicationContext().LOCATION_SERVICE);
        // GPS로 부터 위치 정보를 업데이트 요청
        locManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, this);
        // 기지국으로부터 위치 정보를 업데이트 요청
        locManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 1000, 0, this);
        // 주소를 가져오기 위해 설정 - KOREA, KOREAN 모두 가능 
        geoCoder = new Geocoder(this, Locale.KOREA);
		
		
		
		
		
		img_mypoint.setOnClickListener(new OnClickListener() {
			//운동량  텍스트 클릭시
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
			
				Log.e("mypoint", "my");
				getGeoLocation();
				
			}
		});
		
		img_mypoint1.setOnClickListener(new OnClickListener() {
			//운동량  텍스트 클릭시
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
			
				Log.e("mypoint", "my");
				getGeoLocation1();
				
			}
		});
		
		
		tx_btn_weight.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				String s[]= tx1.getText().toString().trim().split("k");
				try{
				if((tx_weight.getText()!="" && tx_weight.getText().toString().matches("[0-9]+"))&& s[0]!="" && s[0]!="- -"){
				double a=Double.parseDouble(s[0])*Double.parseDouble(tx_weight.getText().toString().trim());
				int b=(int) a;
				tx2.setText(b+"kcal");
				// 운동량 표시 
				
				}
				else{
					Toast.makeText(getApplicationContext(), "몸무게 입력이 잘못되었습니다", 1000).show();
					tx2.setText("");
				}
				}
				catch(Exception e){
					Toast.makeText(getApplicationContext(), "잘못 입력 되었습니다", 1000).show();
					
				}
				
				
				
			}
		});
		
	}
	/**
	 * webview ?ъ슜?섍린 ?꾪빐 WebSettings ?ъ슜?섏뿬 ?ㅼ젙
	 */
	@SuppressLint("SetJavaScriptEnabled") public void setWebViewSetting()
	{
		webView.setWebViewClient(new WebViewClient());
		WebSettings webSettings = webView.getSettings();
		webSettings.setJavaScriptEnabled(true);
		webSettings.setJavaScriptCanOpenWindowsAutomatically(true);

		webSettings.setBuiltInZoomControls(false);
		webSettings.setSupportZoom(false);
		webSettings.setPluginState(WebSettings.PluginState.ON_DEMAND);
		webSettings.setSupportMultipleWindows(false);
		webSettings.setBlockNetworkImage(false);
		webSettings.setLoadsImagesAutomatically(true);
		webSettings.setUseWideViewPort(true);
		webSettings.setCacheMode(WebSettings.LOAD_NO_CACHE);

		// 웹뷰 세팅
				
	}
	
	@Override
		protected void onResume() {
			// TODO Auto-generated method stub
			super.onResume();
			locManager = (LocationManager)getSystemService(Context.LOCATION_SERVICE);
	        // GPS로 부터 위치 정보를 업데이트 요청
	        locManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, this);
	        // 기지국으로부터 위치 정보를 업데이트 요청
	        locManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 1000, 0, this);
	        // 주소를 가져오기 위해 설정 - KOREA, KOREAN 모두 가능 
	        geoCoder = new Geocoder(this, Locale.KOREA);
		}
	
	public void getGeoLocation() {
		  Log.e("a","1");
		  StringBuffer mAddress = new StringBuffer();
		  if(myLocation != null) {
		   latPoint = myLocation.getLatitude();
		   lngPoint = myLocation.getLongitude();
		   try {
		    // 위도,경도를 이용하여 현재 위치의 주소를 가져온다.
			   Log.e("a","2");
		    List<Address> addresses;
		    addresses = geoCoder.getFromLocation(latPoint, lngPoint, 1);
		    Log.e("a","3");
		    for(Address addr: addresses){
		     int index = addr.getMaxAddressLineIndex();
		     for(int i=0;i<=index;i++){
		      mAddress.append(addr.getAddressLine(i));
		      mAddress.append(" ");
		     }
		     mAddress.append("\n");
		    }
		   } catch (IOException e) {
		    e.printStackTrace();
		   }
		   webView.loadUrl("javascript:setMessage('" +mAddress + "')");
		   Log.e("a","Address : " + mAddress);
		   // 좌표를 가지고 주소 변환 (내 주소를 웹 php 에 뿌려주는부분)
		   
		  }
		  
	}
	public void getGeoLocation1() {
		  Log.e("a","1");
		  StringBuffer mAddress = new StringBuffer();
		  if(myLocation != null) {
		   latPoint = myLocation.getLatitude();
		   lngPoint = myLocation.getLongitude();
		   try {
		    // 위도,경도를 이용하여 현재 위치의 주소를 가져온다.
			   Log.e("a","2");
		    List<Address> addresses;
		    addresses = geoCoder.getFromLocation(latPoint, lngPoint, 1);
		    Log.e("a","3");
		    for(Address addr: addresses){
		     int index = addr.getMaxAddressLineIndex();
		     for(int i=0;i<=index;i++){
		      mAddress.append(addr.getAddressLine(i));
		      mAddress.append(" ");
		     }
		     mAddress.append("\n");
		    }
		   } catch (IOException e) {
		    e.printStackTrace();
		   }
		   webView.loadUrl("javascript:setMessage1('" +mAddress + "')");
		   Log.e("a","Address : " + mAddress);
		   // 좌표를 가지고 주소 변환 (내 주소를 웹 php 에 뿌려주는부분)
		   
		  }
		  
	}
	@Override
	public void onLocationChanged(Location arg0) {
		// TODO Auto-generated method stub
		 myLocation = arg0;
		
	}
	@Override
	public void onProviderDisabled(String arg0) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void onProviderEnabled(String arg0) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void onStatusChanged(String arg0, int arg1, Bundle arg2) {
		// TODO Auto-generated method stub
		
	}
	
	

	 private void setbtnexe() {
			// TODO Auto-generated method stub
		 tx11.setOnClickListener(new OnClickListener(
				 ) {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				startActivity(new Intent(getApplicationContext(),Story.class));
				finish();
				
			}
		});
		 tx22.setOnClickListener(new OnClickListener(
				 ) {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				startActivity(new Intent(getApplicationContext(),MainActivity.class));
			}
		});
		 tx33.setOnClickListener(new OnClickListener(
				 ) {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				startActivity(new Intent(getApplicationContext(),Story1.class));
			}
		});
		 
			img3.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					startActivity(new Intent(getApplicationContext(),Story.class));
				}
			});
			
			img4.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View arg0) {
					// TODO Auto-generated method stub
				startActivity(new Intent(getApplicationContext(),Write.class));
					
				}
			});
img2.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View arg0) {
					// TODO Auto-generated method stub
				startActivity(new Intent(getApplicationContext(),Mystory.class));
					
				}
			});

img5.setOnClickListener(new OnClickListener() {
	
	@Override
	public void onClick(View arg0) {
		// TODO Auto-generated method stub
	startActivity(new Intent(getApplicationContext(),Setting.class));
		
	}
});

	 }
	 
}

class androidbrd{
	
	@JavascriptInterface
	 public void loadinglng(String a){
		
		MainActivity.tx1.setText(a+"km");
		MainActivity.arrange=a;
		
		
		
	}
	
	// 웹 php 자바스크립트에서 받아서 처리하는 부분 ( 안드로이드 - 자바스크립트통신)
	
}
