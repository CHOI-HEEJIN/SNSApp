package co.kr.newp;

import java.util.ArrayList;

public class G {
static boolean islogin;
static ArrayList<Data_content> arr=new ArrayList<Data_content>();
static int ischoice;
static ArrayList<Data_reply> arr_reply=new ArrayList<Data_reply>();

}
