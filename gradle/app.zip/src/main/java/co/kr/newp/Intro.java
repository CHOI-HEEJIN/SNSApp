package co.kr.newp;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.Window;
import android.view.WindowManager;

public class Intro extends Activity{
	
	Handler handle;
	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		//??댄?諛??놁븷湲?
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
		setContentView(R.layout.activity_intro);
		handle = new Handler();
		//3珥??숈븞???명듃濡??붾㈃
		handle.postDelayed(rIntent, 3000);
		
	}
	Runnable rIntent = new Runnable() {
		
		@Override
		public void run() {
			// TODO Auto-generated method stub
			Intent Main = new Intent(Intro.this,Login.class);
			startActivity(Main);
			finish();
			
			//fade in?쇰줈 ?쒖옉?섏뿬 fade out?쇰줈 ?명듃濡??붾㈃??爰쇱?寃??좊땲硫붿씠???④낵 ?곸슜
			overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
		}
	};
	@Override
	public void onBackPressed() {
		// TODO Auto-generated method stub
		super.onBackPressed();
		handle.removeCallbacks(rIntent);
	}
	
}
