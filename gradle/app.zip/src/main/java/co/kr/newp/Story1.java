package co.kr.newp;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageView;
import android.widget.TextView;

public class Story1 extends Activity {
	ImageView img2,img3,img4,img5;
	TextView tx11,tx22,tx33;
	WebView webView;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_story1);
		tx11=(TextView) findViewById(R.id.tx1);
		tx22=(TextView) findViewById(R.id.tx2);
		tx33=(TextView) findViewById(R.id.tx3);
		img2=(ImageView) findViewById(R.id.img2);
		img3=(ImageView) findViewById(R.id.img3);
		img4=(ImageView) findViewById(R.id.img4);
		img5=(ImageView) findViewById(R.id.img5);
		webView=(WebView) findViewById(R.id.wb1);
		
		setWebViewSetting();
		webView.loadUrl("http://m.kma.go.kr/m/nation/today.jsp");

		setbtnexe();
		
		
		
	}
	 private void setbtnexe() {
			// TODO Auto-generated method stub
		 tx11.setOnClickListener(new OnClickListener(
				 ) {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				startActivity(new Intent(getApplicationContext(),Story.class));
				finish();
				
			}
		});
		 tx22.setOnClickListener(new OnClickListener(
				 ) {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				startActivity(new Intent(getApplicationContext(),MainActivity.class));
			}
		});
		 tx33.setOnClickListener(new OnClickListener(
				 ) {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				startActivity(new Intent(getApplicationContext(),Story1.class));
			}
		});
		 
			img3.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					startActivity(new Intent(getApplicationContext(),Story.class));
				}
			});
			
			img4.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View arg0) {
					// TODO Auto-generated method stub
				startActivity(new Intent(getApplicationContext(),Write.class));
					
				}
			});
img2.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View arg0) {
					// TODO Auto-generated method stub
				startActivity(new Intent(getApplicationContext(),Mystory.class));
					
				}
			});

img5.setOnClickListener(new OnClickListener() {
	
	@Override
	public void onClick(View arg0) {
		// TODO Auto-generated method stub
	startActivity(new Intent(getApplicationContext(),Setting.class));
		
	}
});

	 }
	 
	 
	 public void setWebViewSetting()
		{
			webView.setWebViewClient(new WebViewClient());
			WebSettings webSettings = webView.getSettings();
			webSettings.setJavaScriptEnabled(true);
			webSettings.setJavaScriptCanOpenWindowsAutomatically(true);

			webSettings.setBuiltInZoomControls(false);
			webSettings.setSupportZoom(false);
			webSettings.setPluginState(WebSettings.PluginState.ON_DEMAND);
			webSettings.setSupportMultipleWindows(false);
			webSettings.setBlockNetworkImage(false);
			webSettings.setLoadsImagesAutomatically(true);
			webSettings.setUseWideViewPort(true);
			webSettings.setCacheMode(WebSettings.LOAD_NO_CACHE);

		}

}
